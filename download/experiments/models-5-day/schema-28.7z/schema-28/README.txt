These are base scenarios with the various model parameterisations used with the
5-day time step models.

Copy this schema-XX folder of XMLs into your experiment "description"
directory, and (optionally) rename it "models". For use with the experiment
creator, one of these *must* be renamed:

*   If you already have a base scenario for your experiment, find whichever
    model uses the same parameters as your base scenario and rename this model
    to base.xml
*   If you haven't yet started creating XML files for your experiment, you can
    instead take any one of these models, rename it base.xml, then copy it to
    the parent directory ("description" dir of experiment) and edit it as your
    base scenario.

