This is a simple example experiment, with:

*  a "CMC" sweep with some arms
*  a sweep of models

To generate scenario files with the experiment_creator, run with --stddirs pointing to the directory *above* the description directory, e.g.:

java ExpcreatorStandalone --stddirs experiment_creator_28 --seeds 3 --name test-experiment

