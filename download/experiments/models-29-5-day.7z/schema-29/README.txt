These are base scenarios with the various model parameterisations used with the
5-day time step models.

They are minimal: the demography, monitoring, interventions, healthSystem and
entomology elements have been removed. Because of this you must run the
experiment creator with the --no-validation option.

Copy this schema-XX folder of XMLs into your experiment "description"
directory, and (optionally) rename it "models". Delete this README.txt file,
and, for use with the experiment creator, one of these *must* be renamed:

*   If you already have a base scenario for your experiment, find whichever
    model uses the same parameters as your base scenario and rename this model
    to base.xml
*   If you haven't yet started creating XML files for your experiment, you can
    instead take any one of these models, rename it base.xml, then copy it to
    the parent directory ("description" dir of experiment) and edit it as your
    base scenario.

Finally, you can run the experiment creator, as described elsewhere:
java -jar ExperimentCreator.jar --stddirs path/to/my_experiment --seeds 3 --no-validation