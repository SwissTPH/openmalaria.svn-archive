This is an offline-readable dump of the OpenMalaria wiki as of 17th Feb, 2011.
To browse it, extract, then navigate to and open
code.google.com/p/openmalaria/wiki/Start in your browser. Bookmark it if you like.

The most up-to-date content should be found at:
http://code.google.com/p/openmalaria/wiki/Start?tm=6

To create another dump like this, use wget:
wget -r -l1 -p -H -Dgstatic.com,code.google.com -e robots=off --convert-links http://code.google.com/p/openmalaria/wiki

Content within the code.google.com/p/openmalaria directory is copyright the
Swiss Tropical and Public Health Institute, Basel, Switzerland, 2005-2011.

